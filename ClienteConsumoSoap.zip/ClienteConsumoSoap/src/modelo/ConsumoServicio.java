/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import sv.Servicios;
import sv.Servicios_Service;

/**
 *
 * @author Pc
 */
public class ConsumoServicio {
    public static void main(String[] args) {
        Servicios_Service ser = new Servicios_Service() ;
        Servicios cliente = ser.getServiciosPort();
        System.out.println(cliente.hello("Edisson"));
        System.out.println(cliente.potencia(2.0,3.0)+" Potencia");
        System.out.println(cliente.parOInpar(32)+ " Par o Impar");
        System.out.println(cliente.diccionario("Java")+"Diccionario");

        if(cliente.login("EdissonQuinde", "lacow")){
            System.out.println("Datos Correctos");
        }else{
            System.out.println("Datos Incorrectos");
        }
        //operaciones basicas
        System.out.println(cliente.suma(12.0,30.0)+" Suma");
        System.out.println(cliente.resta(15.0,3.0)+" Resta");
        System.out.println(cliente.multiplicacion(9.0,9.0)+" Multiplicacion");
        System.out.println(cliente.divicion(98.0,5.0)+" Divicion");
        //formulas fisicas
        System.out.println(cliente.porcentaje(12.0,1250.0)+" Porcentaje");
        System.out.println(cliente.velocidad(10.0,15.0)+" Velocidad");
        System.out.println(cliente.distancia(190.0,10.0)+" Distancia");
    }
}
